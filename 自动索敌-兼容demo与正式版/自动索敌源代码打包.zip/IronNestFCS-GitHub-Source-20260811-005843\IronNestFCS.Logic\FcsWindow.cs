using MelonLoader;
using UnityEngine;

namespace IronNestFCS.Logic;

/// <summary>
/// 火控系统的 IMGUI 窗口。只负责绘制与把用户操作转发给 <see cref="FSC"/>。
/// 不含领域逻辑——按钮点击后调用 logic 的方法。
///
/// 实现说明：在 MelonLoader IL2CPP 下，MelonMod.OnGUI 每帧只触发一次，
/// 无法保证 IMGUI 所需的 Layout / event 多 pass。GUILayout 依赖 Layout pass
/// 预算尺寸，pass 不一致时 controlID 会错位，表现为"只有第一个按钮能点"。
/// 因此这里改用绝对 Rect 的 GUI.* API（不走布局系统），并且不套 GUI.Window
/// （避免回调委托封送丢失 pass）。控件 controlID 仅取决于调用顺序，稳定可靠。
/// </summary>
public class FcsWindow
{
    private readonly FSC fcs;

    private bool showWindow = true;
    private Rect defaultWindowRect = new(40, 40, 300, 226);

    public FcsWindow(FSC fcs)
    {
        this.fcs = fcs;
    }

    public void OnGui()
    {
        if (!showWindow)
            return;

        RequisitionPointsMonitor.Poll();
        var windowRect = defaultWindowRect;

        if (fcs.LeftTask != null) {
            windowRect.height += 28f;
        }
        if (fcs.RightTask != null) {
            windowRect.height += 28f;
        }
        if (RequisitionPointsMonitor.HasCurrentTotal) {
            windowRect.height += 56f;
        }
        windowRect.height += 28f;
        windowRect.height += fcs.QueueCan.Count * 28f;

        // 背景框
        GUI.Box(windowRect, "IronNest FCS");
        
        float x = windowRect.x + 10f;
        float w = windowRect.width - 20f;
        float y = windowRect.y + 25f;
        const float h = 24f;
        const float gap = 4f;

        if (!fcs.IsBound)
        {
            GUI.Label(new Rect(x, y, w, h), "Waiting for game start.");
            y += h + gap;
            GUI.Label(new Rect(x, y, w, h), "Or press F9 to manually reload.");
            return;
        }

        GUI.Label(new Rect(x, y, w, h), "Left Gun:");
        y += h + gap;
        if (fcs.LeftTask != null) {
            GUI.Label(new Rect(x, y, w, h), $"  {TargetLabel(fcs.LeftTask)}{RewardLabel(fcs.LeftTask)} {fcs.LeftTask.bulletType} {fcs.LeftTask.progress}");
            y += h + gap;
            GUI.Label(new Rect(x, y, w, h), $"  Target: {fcs.LeftTask.angel:F1}°, {fcs.LeftTask.distance:F2}km");
            y += h + gap;
        }
        else {
            GUI.Label(new Rect(x, y, w, h), "  Idle");
            y += h + gap;
        }
        GUI.Label(new Rect(x, y, w, h), "Right Gun:");
        y += h + gap;
        if (fcs.RightTask != null) {
            GUI.Label(new Rect(x, y, w, h), $"  {TargetLabel(fcs.RightTask)}{RewardLabel(fcs.RightTask)} {fcs.RightTask.bulletType} {fcs.RightTask.progress}");
            y += h + gap;
            GUI.Label(new Rect(x, y, w, h), $"  Target: {fcs.RightTask.angel:F1}°, {fcs.RightTask.distance:F2}km");
            y += h + gap;
        }
        else {
            GUI.Label(new Rect(x, y, w, h), "  Idle");
            y += h + gap;
        }

        GUI.Label(new Rect(x, y, w, h), $"Queued: {fcs.PendingCount}");
        y += h + gap;
        GUI.Label(new Rect(x, y, w, h),
            $"Auto Target: {(fcs.AutoTargetEnabled ? "ON" : "OFF")}  Detected: {fcs.DetectedEnemyCount}");
        y += h + gap;
        var requisitionMode = fcs.AutoTargetBudgetPaused
            ? "NO FUNDS"
            : RequisitionPointsMonitor.HasCurrentTotal
              && RequisitionPointsMonitor.CurrentTotal < fcs.RequisitionTarget
                ? "RECOVER"
                : "READY";
        GUI.Label(new Rect(x, y, w, h),
            $"RP Mode: {requisitionMode}  Target: {fcs.RequisitionTarget}");
        y += h + gap;
        GUI.Label(new Rect(x, y, w, h),
            $"Valves: {fcs.DetectedValveCount}  Loose: {fcs.LooseValveCount}  Auto-fixed: {fcs.RepairedValveCount}");
        y += h + gap;
        if (RequisitionPointsMonitor.HasCurrentTotal) {
            GUI.Label(new Rect(x, y, w, h),
                $"RP Total: {RequisitionPointsMonitor.CurrentTotal}");
            y += h + gap;
            GUI.Label(new Rect(x, y, w, h),
                RequisitionPointsMonitor.HasLastAward
                    ? $"Last reward: +{RequisitionPointsMonitor.LastAwardAmount} ({RequisitionPointsMonitor.LastSource})"
                    : "Last reward: waiting for change");
            y += h + gap;
        }
        foreach (var item in fcs.QueueCan)
        {
            GUI.Label(new Rect(x, y, w, h), $"  {TargetLabel(item)}{RewardLabel(item)} {ConvertPosition(item.position)} {item.angel,5:F1}°/{item.distance,5:F2}km {item.bulletType} ");
            y += h + gap;
        }

    }

    private static string TargetLabel(IronNestFCS.Logic.FCS.ArtilleryTask task)
    {
        var name = string.IsNullOrWhiteSpace(task.targetName) ? $"T{task.targetId}" : task.targetName;
        if (task.isArtillery) return $"[ART] {name}";
        if (task.isCommander) return $"[FDC] {name}";
        if (task.isSupply) return $"[SUP] {name}";
        if (task.isMechanized) return $"[MECH] {name}";
        if (task.isRecon) return $"[REC] {name}";
        return task.isInfantry ? $"[INF] {name}" : name;
    }

    private static string RewardLabel(IronNestFCS.Logic.FCS.ArtilleryTask task)
    {
        return task.sourceRewardPoints >= 0 ? $" R+{task.sourceRewardPoints}" : "";
    }

    /// <summary> 计算坐标点所对应的区域字符串 </summary>
    public static string ConvertPosition(Vector3 position)
    {
        int leterIndex = (int)position.x;
        string zoneCol = leterIndex >= 0 && leterIndex < 26 ? ((char)('A' + leterIndex)).ToString() : "#";
        int zoneRow = (int)position.y + 1;
        int subCol = (int)(position.x * 10) % 10;  // B: 第一位小数
        int subRow = (int)(position.y * 10) % 10;  // B: 第一位小数

        return $"{zoneCol}{zoneRow}  {subCol}:{subRow}";
    }
}
