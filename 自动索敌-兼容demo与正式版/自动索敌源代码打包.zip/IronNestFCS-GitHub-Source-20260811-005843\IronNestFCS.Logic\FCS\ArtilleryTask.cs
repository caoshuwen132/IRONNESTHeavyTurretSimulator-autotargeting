﻿using UnityEngine;

using Il2Cpp;

namespace IronNestFCS.Logic.FCS;

public enum Progress {
    Pending,
    Calculating,
    SelectingBullet,
    LoadingBullet,
    LoadingPowder,
    WaitLoading,
    Aiming,
    WaitingForFire,
    BackToIdle,
    Finished,
    Failed,
}

public class ArtilleryTask {
    public int targetId;
    public string targetName = "";
    public string sourceEntityId = "";
    public bool isAutoTarget;
    public bool isUnderground;
    public bool requiresAp;
    public bool isCommander;
    public bool isArtillery;
    public bool isSupply;
    public bool isMechanized;
    public bool isRecon;
    public bool isInfantry;
    public string sourceIcon = "";
    public string sourceIconSprite = "";
    public string sourceStatusSprites = "";
    public string sourceImmuneShells = "";
    public int sourceRewardPoints = -1;
    public string sourceRewardSource = "";
    public int sourceHealth;
    public int sourceMaxHealth;
    public int sourceArmour;
    public int sourceStars;
    public EntityRoles sourceRole;
    public MapEntityStates sourceState;
    public float angel;
    public float distance;
    public Vector3 position;
    public BulletType bulletType;
    public Progress progress;
}
