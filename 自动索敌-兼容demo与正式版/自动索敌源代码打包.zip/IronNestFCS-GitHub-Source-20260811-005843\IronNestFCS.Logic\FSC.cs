using HarmonyInstance = HarmonyLib.Harmony;
using System.Collections;
using Il2Cpp;
using IronNestFCS.Logic.FCS;
using MelonLoader;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace IronNestFCS.Logic;

public enum LeftRight {
    Left,
    Right,
}

/// <summary>
/// 纯火控领域逻辑：查找游戏对象、读取游戏数据、操控游戏内交互（dial 等）。
/// 不含任何 UI / IMGUI / 生命周期框架代码——那些在 <see cref="FcsModule"/> 和 <see cref="FcsWindow"/> 里。
///
/// 重载安全规则：
///  - 不要在这里注册新的 IL2CPP 类型（同一类型进程内只能注册一次）。
///  - 每次实例用独立的 Harmony 实例；Shutdown 时 UnpatchSelf。
///  - 所有对 IL2CPP 对象的引用在 Shutdown 时清空，便于旧 ALC 回收。
/// </summary>
public class FSC
{
    private const string HarmonyId = "com.svr2kos2.ironnestfcs.logic";

    // ===== 药包自动补充 =====
    // 两炮共用一个装药余量池：余量低于 PowderReplenishThreshold 时，每 PowderCheckInterval 秒
    // 自动购买一次装药卡，把药包维持在充足水位，避免任务流程因装药不足卡在装填/击发阶段。
    // 只做检测与补充，不干预 RunTaskRoutine 里的任何现有步骤。
    private const float PowderCheckInterval = 5f;
    private const int PowderReplenishThreshold = 6;
    private const float AutoTargetScanInterval = 2f;
    private const float ValveMaintenanceInterval = 0.5f;
    private const float ValveLooseThreshold = 0.001f;
    private const int AutoTargetCapacity = 2;
    private const float AutoTargetRetryDelay = 20f;
    private const float TargetOutcomeTimeout = 180f;
    private const int AutoShellCost = 3;
    private const int DesiredRequisitionFloor = 50;
    private const int AbsoluteRequisitionReserve = 1;
    private const int ScoringInterleaveThreshold =
        DesiredRequisitionFloor + AutoShellCost * AutoTargetCapacity;

    private HarmonyInstance? _harmony;
    
    private FcsSceneInteractor _sceneInteractor;
    private readonly PurchaseDeck _purchaseDeck = new();
    public readonly MapTable MapTable = new MapTable();
    public readonly BallisticCalculator BallisticCalculator = new BallisticCalculator();
    public readonly GunSystem LeftGun = new GunSystem();
    public readonly GunSystem RightGun = new GunSystem();
    public readonly Turret Turret = new Turret();
    public readonly TriggerConsole TriggerConsole = new();
    
    // ===== 任务调度 =====
    // 用户不再指定炮管：任务入队后由调度器派给空闲炮管，炮管打完一发自动拉下一个。
    // 所有读写都在 Unity 主线程（入队来自点击回调，派发/完成来自协程），无并发，无需锁。
    private readonly Queue<ArtilleryTask> _taskQueue = new();
    private readonly HashSet<string> _autoTargetIds = new();
    private readonly Dictionary<string, float> _autoTargetRetryAfter = new();
    private readonly HashSet<string> _destroyedTargetIds = new();
    private readonly List<PendingTargetOutcome> _pendingTargetOutcomes = new();
    private bool _targetStatsInitialized;
    private int _lastTargetsDestroyed;
    private int _lastHitsOnTargets;
    private int _lastMissedShots;
    private int _untrackedShotsInFlight;
    // 炮兵与 FDC 同时可用时，首次从炮兵开始，此后在两个类别之间交替。
    private bool _preferArtilleryNext = true;
    private bool _budgetPauseLogged;
    private bool _powderBudgetPauseLogged;
    private int _lastLoggedValveCount = -1;

    /// <summary>当前各炮管正在执行的任务；null 表示该炮管空闲。供 UI 显示与调度判断。</summary>
    public ArtilleryTask? LeftTask { get; private set; }
    public ArtilleryTask? RightTask { get; private set; }

    /// <summary>等待派发的任务数（已入队但还没分到炮管）。供 UI 显示。</summary>
    public int PendingCount => _taskQueue.Count;
    public Queue<ArtilleryTask> QueueCan => new Queue<ArtilleryTask>(_taskQueue);
    public bool AutoTargetEnabled => _sceneInteractor.AutoTarget;
    public int DetectedEnemyCount { get; private set; }
    public bool AutoTargetBudgetPaused { get; private set; }
    public int RequisitionTarget => DesiredRequisitionFloor;
    public int DetectedValveCount { get; private set; }
    public int LooseValveCount { get; private set; }
    public int RepairedValveCount { get; private set; }

    /// <summary>
    /// 控制台互斥锁：保护弹道计算器、确认开关台、采购台这三组全局唯一的"短操作"硬件。
    /// 临界区都很短（解算 / 确认弹 / 击发前的确认+击发），用完即放。
    /// </summary>
    private readonly CoroutineLock _deskLock = new();

    /// <summary>
    /// 炮塔方向角锁：方向角是全炮塔共享的，且一旦为某任务转到位，必须独占到这一发打出去为止
    /// （中途被另一任务转走就会打偏）。与 <see cref="_deskLock"/> 分开，是为了让本任务能在
    /// 后台早早抢占炮塔、与装填/升仰角重叠，而不挡住另一管炮在 deskLock 上的解算。
    ///
    /// 防死锁：凡同时需要两把锁处，一律"先 turret 后 desk"。本类只有击发段会嵌套两把锁
    /// （此时炮塔已由后台预约持有，再去抢 desk），解算/确认弹只单独用 desk，故无环、不死锁。
    /// </summary>
    private readonly CoroutineLock _turretLock = new();

    // 正在运行的协程句柄。Dispose 时全部停掉，避免热重载后旧 ALC 的协程继续执行导致崩溃。
    private readonly List<object> _runningCoroutines = new();
    public FSC() {
        this._sceneInteractor = new FcsSceneInteractor(this);
    }

    public bool IsBound { get; private set; } = false;

    /// <summary>查找并绑定游戏对象。返回 false 表示当前场景还没有目标控件。</summary>
    public bool TryBind()
    {
        // 每次重载创建全新的 Harmony 实例，避免与上一版补丁冲突。
        _sceneInteractor = new FcsSceneInteractor(this);
        _sceneInteractor.Initialize();
        _harmony = new HarmonyInstance(HarmonyId);
        _deskLock.Reset();
        _turretLock.Reset();
        IsBound = MapTable.TryBind()
                  && BallisticCalculator.TryBind()
                  && LeftGun.TryBind("Left")
                  && RightGun.TryBind("Right")
                  && _purchaseDeck.TryBind()
                  && Turret.TryBind()
                  && TriggerConsole.TryBind();
        MelonLogger.Msg("[FCS] Initialize: " + (IsBound ? "success" : "failed"));
        if (IsBound) {
            RequisitionPointsMonitor.Install(_harmony);
            InitializeTargetOutcomeTracking();
            // 常驻药包自动补充协程：仅保证装药余量充足，不改动任务流程。
            _runningCoroutines.Add(MelonCoroutines.Start(ReplenishPowderLoop()));
            _runningCoroutines.Add(MelonCoroutines.Start(AutoTargetLoop()));
            _runningCoroutines.Add(MelonCoroutines.Start(MaintainPressureValvesLoop()));
        }
        // _runningCoroutines.Add(MelonCoroutines.Start(ExposeAllEntities()));
        
        return IsBound;
    }

    public void Update() {
        _sceneInteractor.Update();
    }
    
    /// <summary>释放：撤销补丁、清空 IL2CPP 引用。</summary>
    public void Dispose()
    {
        // 停掉所有未完成的协程，否则热重载后旧 ALC 的协程仍会被 Unity 驱动 → 崩溃。
        foreach (var handle in _runningCoroutines) {
            try { MelonCoroutines.Stop(handle); }
            catch (Exception ex) { MelonLogger.Error($"[FCS] Stop coroutines failed: {ex}"); }
        }
        _runningCoroutines.Clear();

        // 清空调度状态，避免热重载后残留任务/槽位影响新一轮绑定。
        _taskQueue.Clear();
        _autoTargetIds.Clear();
        _autoTargetRetryAfter.Clear();
        _destroyedTargetIds.Clear();
        _pendingTargetOutcomes.Clear();
        _targetStatsInitialized = false;
        _lastTargetsDestroyed = 0;
        _lastHitsOnTargets = 0;
        _lastMissedShots = 0;
        _untrackedShotsInFlight = 0;
        _preferArtilleryNext = true;
        _budgetPauseLogged = false;
        _powderBudgetPauseLogged = false;
        _lastLoggedValveCount = -1;
        AutoTargetBudgetPaused = false;
        LeftTask = null;
        RightTask = null;
        DetectedEnemyCount = 0;
        DetectedValveCount = 0;
        LooseValveCount = 0;
        RepairedValveCount = 0;

        _sceneInteractor.ShutDown();
        try { _harmony?.UnpatchSelf(); }
        catch (Exception ex) { MelonLogger.Error($"[FCS] UnpatchSelf failed: {ex}"); }
        _harmony = null;
    }

    /// <summary>
    /// 常驻后台协程：周期性检测装药余量（两炮共用池），低于阈值时自动购买一次装药卡。
    /// 购买必须持 _deskLock——采购台是共享硬件，与任务流程的采购互斥（阻塞等待，不破坏临界区）。
    /// 必须在 TryBind 成功后启动并登记进 _runningCoroutines；Dispose 时随其它协程一起 Stop，
    /// 迭代器被 Stop 时 Dispose 会执行 finally，锁不会泄漏。
    /// </summary>
    private IEnumerator ReplenishPowderLoop() {
        while (true) {
            yield return new WaitForSeconds(PowderCheckInterval);
            // 两炮共用一个装药余量池，读数应一致；取较小值保守触发。
            var charges = Math.Min(LeftGun.RemainingCharges(), RightGun.RemainingCharges());
            if (charges >= PowderReplenishThreshold) continue;
            var powderCost = _purchaseDeck.GetPowderCost();
            if (!CanSpendKeepingDesiredFloor(powderCost)) {
                if (!_powderBudgetPauseLogged) {
                    MelonLogger.Warning(
                        $"[FCS] AutoReplenish: RP budget paused " +
                        $"(total={RequisitionPointsMonitor.CurrentTotal}, cost={powderCost}, " +
                        $"targetFloor={DesiredRequisitionFloor})");
                    _powderBudgetPauseLogged = true;
                }
                continue;
            }
            _powderBudgetPauseLogged = false;
            MelonLogger.Msg(
                $"[FCS] AutoReplenish: powder charges {charges} < {PowderReplenishThreshold}, buying one");
            yield return _deskLock.Acquire();
            try {
                yield return _purchaseDeck.BuyPowders();
            }
            finally {
                _deskLock.Release();
            }
        }
    }

    /// <summary>
    /// 自动检查当前场景中的高压系统阀门。Damage01 大于零表示阀门已经松动；
    /// 使用游戏原生 ForceFixValve 动作复位旋钮并同步压力系统及相关事件。
    /// </summary>
    private IEnumerator MaintainPressureValvesLoop() {
        while (true) {
            // 使用实时时间，即使玩家暂停查看面板，也能完成阀门检测与拧紧。
            yield return new WaitForSecondsRealtime(ValveMaintenanceInterval);

            var activeCount = 0;
            var looseCount = 0;
            var valves = Resources.FindObjectsOfTypeAll<ValveController>();
            foreach (var valve in valves) {
                if (valve == null || valve.gameObject == null || !valve.gameObject.activeInHierarchy) continue;
                activeCount++;

                float damage;
                try {
                    damage = valve.Damage01;
                }
                catch (Exception ex) {
                    MelonLogger.Warning($"[FCS] Valve monitor: cannot read {valve.name}: {ex.Message}");
                    continue;
                }
                if (damage <= ValveLooseThreshold) continue;

                looseCount++;
                var systemId = string.IsNullOrEmpty(valve.systemId) ? "unknown" : valve.systemId;
                var dialBefore = valve.CurrentDialValue;
                try {
                    valve.ForceFixValve();
                    if (valve.Damage01 <= ValveLooseThreshold) {
                        RepairedValveCount++;
                        MelonLogger.Msg(
                            $"[FCS] Valve maintenance: tightened {valve.name} " +
                            $"(system={systemId}, damage={damage:F3}, dial={dialBefore:F3}->{valve.CurrentDialValue:F3})");
                    }
                    else {
                        MelonLogger.Warning(
                            $"[FCS] Valve maintenance: {valve.name} remained loose " +
                            $"(system={systemId}, damage={damage:F3}->{valve.Damage01:F3})");
                    }
                }
                catch (Exception ex) {
                    MelonLogger.Warning($"[FCS] Valve maintenance: failed to tighten {valve.name}: {ex.Message}");
                }
            }

            DetectedValveCount = activeCount;
            LooseValveCount = looseCount;
            if (_lastLoggedValveCount != activeCount) {
                MelonLogger.Msg($"[FCS] Valve maintenance: monitoring {activeCount} active valves");
                _lastLoggedValveCount = activeCount;
            }
        }
    }

    /// <summary>
    /// 自动索敌只补满当前两条炮管任务槽，不无限堆积队列。
    /// 候选目标由 MapTable 过滤友军、隐藏、移动和已摧毁实体，并按距离排序。
    /// </summary>
    private IEnumerator AutoTargetLoop() {
        while (true) {
            yield return new WaitForSeconds(AutoTargetScanInterval);

            // 无论自动索敌开关是否开启，都要结算已经发射的手动/自动任务。
            // 目标在炮弹落地前始终保持占用，避免远距离弹道尚未命中就被第三发重复选择。
            PollTargetOutcomes();

            if (!_sceneInteractor.AutoTarget) {
                DetectedEnemyCount = 0;
                _preferArtilleryNext = true;
                AutoTargetBudgetPaused = false;
                _budgetPauseLogged = false;
                continue;
            }

            RequisitionPointsMonitor.Poll();

            var candidates = MapTable.GetAutoTargets(_sceneInteractor.selectedBulletType);
            DetectedEnemyCount = candidates.Count;

            var occupied = _taskQueue.Count;
            if (LeftTask != null) occupied++;
            if (RightTask != null) occupied++;
            var available = AutoTargetCapacity - occupied;
            var committedShells = CountPendingAutoShellPurchases();
            AutoTargetBudgetPaused = false;
            if (available <= 0) continue;

            var eligible = new List<ArtilleryTask>();
            foreach (var task in candidates) {
                if (_destroyedTargetIds.Contains(task.sourceEntityId)) continue;
                if (_autoTargetRetryAfter.TryGetValue(task.sourceEntityId, out var retryAfter)) {
                    if (Time.realtimeSinceStartup < retryAfter) continue;
                    _autoTargetRetryAfter.Remove(task.sourceEntityId);
                }
                if (_autoTargetIds.Contains(task.sourceEntityId)) continue;
                eligible.Add(task);
            }

            while (available > 0 && eligible.Count > 0) {
                committedShells = CountPendingAutoShellPurchases();
                var task = SelectNextAutoTarget(eligible);
                var purchaseCost = EstimateNextAutoTaskPurchaseCost(task);
                if (!CanFundAutoTask(committedShells, purchaseCost)) {
                    AutoTargetBudgetPaused = true;
                    if (!_budgetPauseLogged) {
                        var total = RequisitionPointsMonitor.HasCurrentTotal
                            ? RequisitionPointsMonitor.CurrentTotal.ToString()
                            : "unknown";
                        MelonLogger.Warning(
                            $"[FCS] AutoTarget: insufficient RP to preserve the absolute reserve " +
                            $"(total={total}, target={task.targetName}, " +
                            $"committedShells={committedShells}, purchaseCost={purchaseCost})");
                        _budgetPauseLogged = true;
                    }
                    break;
                }
                _budgetPauseLogged = false;

                eligible.Remove(task);
                if (!_autoTargetIds.Add(task.sourceEntityId)) continue;

                MelonLogger.Msg(
                    $"[FCS] AutoTarget: acquired {task.targetName} [{task.sourceEntityId}] " +
                    $"({task.angel:F1} deg, {task.distance:F2} km, " +
                    $"HP {task.sourceHealth}/{task.sourceMaxHealth}, armour {task.sourceArmour}, " +
                    $"stars {task.sourceStars}, role {task.sourceRole}, " +
                    $"state {task.sourceState}, " +
                    $"icon={task.sourceIcon}, sprite={task.sourceIconSprite}, " +
                    $"statusSprites=[{task.sourceStatusSprites}], " +
                    $"immune=[{task.sourceImmuneShells}], reward={RewardLogValue(task)}, " +
                    $"rewardSource={task.sourceRewardSource}, artillery={task.isArtillery}, " +
                    $"commander={task.isCommander}, supply={task.isSupply}, " +
                    $"mechanized={task.isMechanized}, recon={task.isRecon}, " +
                    $"infantry={task.isInfantry}, estimatedReward={EstimatedScoringReward(task)}, " +
                    $"underground={task.isUnderground}, requiresAP={task.requiresAp}, " +
                    $"shell={task.bulletType})");
                EnqueueTask(task);
                available--;
            }
        }
    }

    private bool CanFundAutoTask(int committedShells, int nextShellCost) {
        if (!RequisitionPointsMonitor.HasCurrentTotal) return false;
        var projected = RequisitionPointsMonitor.CurrentTotal
                        - committedShells * AutoShellCost
                        - nextShellCost;
        return projected >= AbsoluteRequisitionReserve;
    }

    private static bool CanSpendKeepingDesiredFloor(int cost) {
        if (cost <= 0) return true;
        RequisitionPointsMonitor.Poll();
        return RequisitionPointsMonitor.HasCurrentTotal
               && RequisitionPointsMonitor.CurrentTotal - cost >= DesiredRequisitionFloor;
    }

    private static bool CanSpendForAutoTask(int cost) {
        if (cost <= 0) return true;
        RequisitionPointsMonitor.Poll();
        return RequisitionPointsMonitor.HasCurrentTotal
               && RequisitionPointsMonitor.CurrentTotal - cost >= AbsoluteRequisitionReserve;
    }

    private static bool IsScoringTarget(ArtilleryTask task) {
        // 实测 OptionalTarget/Tank（机械化）命中后不增加征用积分。
        // 机械化仍保留战术分类和常规排序，但不能再承担低分恢复任务。
        return task.isSupply || task.isRecon;
    }

    private static int EstimatedScoringReward(ArtilleryTask task) {
        if (!IsScoringTarget(task)) return 0;
        if (task.sourceRewardPoints > 0) return task.sourceRewardPoints;
        return Math.Max(1, task.sourceStars) * 10;
    }

    private int EstimateNextAutoTaskPurchaseCost(ArtilleryTask task) {
        var gunSys = LeftTask == null ? LeftGun : RightGun;
        var cost = gunSys.HaveBulletInCylinder(task.bulletType)
            ? 0
            : Math.Max(0, _purchaseDeck.GetShellCost(task.bulletType));

        var powderCount = _sceneInteractor.maxCharge
            ? 6
            : BallisticCalculator.MinimumCharge(task.distance);
        if (gunSys.RemainingCharges() < powderCount) {
            cost += Math.Max(0, _purchaseDeck.GetPowderCost());
        }
        return cost;
    }

    private int CountPendingAutoShellPurchases() {
        var count = 0;
        if (NeedsAutoShellBudget(LeftTask)) count++;
        if (NeedsAutoShellBudget(RightTask)) count++;
        foreach (var task in _taskQueue) {
            if (NeedsAutoShellBudget(task)) count++;
        }
        return count;
    }

    private static bool NeedsAutoShellBudget(ArtilleryTask? task) {
        if (task == null || !task.isAutoTarget) return false;
        return task.progress == Progress.Pending
               || task.progress == Progress.Calculating
               || task.progress == Progress.SelectingBullet;
    }

    /// <summary>
    /// 战术优先级：炮兵与指挥官高于普通目标；两者同时存在时从炮兵开始交替攻击。
    /// 某一高优先类别暂时为空时立即选择另一类，不让空闲炮管等待。
    /// </summary>
    private ArtilleryTask SelectNextAutoTarget(List<ArtilleryTask> candidates) {
        var artillery = FindBestCandidate(candidates, task => task.isArtillery);
        var commander = FindBestCandidate(candidates, task => task.isCommander);
        var scoring = FindBestCandidate(
            candidates,
            IsScoringTarget,
            CompareStarsFirst);
        var support = FindBestCandidate(
            candidates,
            task => task.isSupply || task.isMechanized || task.isRecon,
            CompareStarsFirst);
        var other = FindBestCandidate(candidates,
            task => !task.isArtillery && !task.isCommander
                    && !task.isSupply && !task.isMechanized && !task.isRecon
                    && !task.isInfantry);
        var infantry = FindBestCandidate(candidates, task => task.isInfantry);
        var prioritizeScoring = scoring != null
                                && RequisitionPointsMonitor.HasCurrentTotal
                                && RequisitionPointsMonitor.CurrentTotal <= ScoringInterleaveThreshold;

        ArtilleryTask selected;
        if (prioritizeScoring) {
            selected = scoring!;
        }
        else if (artillery != null && commander != null) {
            selected = _preferArtilleryNext ? artillery : commander;
        }
        else if (artillery != null) {
            selected = artillery;
        }
        else if (commander != null) {
            selected = commander;
        }
        else if (support != null) {
            selected = support;
        }
        else if (other != null) {
            selected = other;
        }
        else {
            selected = infantry!;
        }

        if (selected.isArtillery) _preferArtilleryNext = false;
        else if (selected.isCommander) _preferArtilleryNext = true;
        return selected;
    }

    /// <summary>同一战术类别内：已知积分高者优先，其次星级高者，最后距离近者。</summary>
    private static ArtilleryTask? FindBestCandidate(
        List<ArtilleryTask> candidates, Predicate<ArtilleryTask> predicate,
        Comparison<ArtilleryTask>? comparison = null) {
        ArtilleryTask? best = null;
        comparison ??= CompareTargetValue;
        foreach (var candidate in candidates) {
            if (!predicate(candidate)) continue;
            if (best == null || comparison(candidate, best) < 0) best = candidate;
        }
        return best;
    }

    private static int CompareStarsFirst(ArtilleryTask a, ArtilleryTask b) {
        var starsOrder = b.sourceStars.CompareTo(a.sourceStars);
        if (starsOrder != 0) return starsOrder;

        var aReward = Math.Max(0, a.sourceRewardPoints);
        var bReward = Math.Max(0, b.sourceRewardPoints);
        var rewardOrder = bReward.CompareTo(aReward);
        if (rewardOrder != 0) return rewardOrder;
        return a.distance.CompareTo(b.distance);
    }

    private static int CompareTargetValue(ArtilleryTask a, ArtilleryTask b) {
        var aReward = Math.Max(0, a.sourceRewardPoints);
        var bReward = Math.Max(0, b.sourceRewardPoints);
        var rewardOrder = bReward.CompareTo(aReward);
        if (rewardOrder != 0) return rewardOrder;

        var starsOrder = b.sourceStars.CompareTo(a.sourceStars);
        if (starsOrder != 0) return starsOrder;
        return a.distance.CompareTo(b.distance);
    }

    private static string RewardLogValue(ArtilleryTask task) {
        return task.sourceRewardPoints >= 0 ? task.sourceRewardPoints.ToString() : "unknown";
    }

    public IEnumerator ExposeAllEntities() {
        while (true) {
            foreach (var m in MapTable.GetAllFireMissionEntities()) {
                var vr = m.transform.FindChild("VisualRoot");
                vr.gameObject.SetActive(true);
                vr.FindChild("Info").gameObject.SetActive(true);
            }
            yield return new WaitForSeconds(1f);
        }
    }

    /// <summary>
    /// 把任务加入调度队列。用户不指定炮管——调度器自动派给空闲炮管。
    /// 入队后立即尝试派发；若两管炮都忙，任务留在队列里，等某管炮打完自动拉取。
    /// 必须在主线程调用（点击回调即是）。
    /// </summary>
    private void InitializeTargetOutcomeTracking() {
        try {
            var tracker = MissionStatsTracker.Instance;
            if (tracker == null) return;
            _lastTargetsDestroyed = tracker.TargetsDestroyed_Mission;
            _lastHitsOnTargets = tracker.HitsOnTargets_Mission;
            _lastMissedShots = tracker.MissedShots_Mission;
            _untrackedShotsInFlight = Math.Max(
                0,
                tracker.ShotsFired_Mission - _lastHitsOnTargets - _lastMissedShots);
            _targetStatsInitialized = true;
            MelonLogger.Msg(
                $"[FCS] Target tracking: baseline destroyed={_lastTargetsDestroyed}, " +
                $"hits={_lastHitsOnTargets}, misses={_lastMissedShots}, " +
                $"untrackedInFlight={_untrackedShotsInFlight}");
        }
        catch (Exception ex) {
            _targetStatsInitialized = false;
            MelonLogger.Warning($"[FCS] Target tracking: baseline failed: {ex.Message}");
        }
    }

    private void PollTargetOutcomes() {
        try {
            var tracker = MissionStatsTracker.Instance;
            if (tracker == null) return;
            if (!_targetStatsInitialized) {
                InitializeTargetOutcomeTracking();
                return;
            }

            var destroyed = tracker.TargetsDestroyed_Mission;
            var hits = tracker.HitsOnTargets_Mission;
            var misses = tracker.MissedShots_Mission;

            if (destroyed < _lastTargetsDestroyed
                || hits < _lastHitsOnTargets
                || misses < _lastMissedShots) {
                _pendingTargetOutcomes.Clear();
                _autoTargetIds.Clear();
                _autoTargetRetryAfter.Clear();
                _destroyedTargetIds.Clear();
                _lastTargetsDestroyed = destroyed;
                _lastHitsOnTargets = hits;
                _lastMissedShots = misses;
                _untrackedShotsInFlight = 0;
                MelonLogger.Msg("[FCS] Target tracking: mission counters reset");
                return;
            }

            var destroyedDelta = destroyed - _lastTargetsDestroyed;
            var hitDelta = hits - _lastHitsOnTargets;
            var missDelta = misses - _lastMissedShots;
            _lastTargetsDestroyed = destroyed;
            _lastHitsOnTargets = hits;
            _lastMissedShots = misses;

            // 热重载时已经在空中的旧炮弹没有对应任务。先消费它们的落点，
            // 防止旧炮弹的命中/未命中结果错误释放刚建立的新目标锁定。
            while (_untrackedShotsInFlight > 0 && (hitDelta > 0 || missDelta > 0)) {
                if (missDelta > 0) {
                    missDelta--;
                }
                else {
                    hitDelta--;
                    if (destroyedDelta > 0) destroyedDelta--;
                }
                _untrackedShotsInFlight--;
                MelonLogger.Msg(
                    $"[FCS] Target tracking: ignored pre-reload outcome, " +
                    $"remaining={_untrackedShotsInFlight}");
            }

            for (var i = 0; i < destroyedDelta; i++) ResolvePendingDestroyedTarget();

            // 摧毁通常也计为命中；剩余命中暂缓数秒，等待可能延迟的摧毁计数。
            var survivingHitDelta = Math.Max(0, hitDelta - destroyedDelta);
            for (var i = 0; i < survivingHitDelta; i++) MarkPendingTargetHit();
            for (var i = 0; i < missDelta; i++) ResolvePendingMissedTarget();

            var now = Time.realtimeSinceStartup;
            for (var i = _pendingTargetOutcomes.Count - 1; i >= 0; i--) {
                var pending = _pendingTargetOutcomes[i];
                if (pending.HitObservedAt > 0f && now - pending.HitObservedAt >= 4f) {
                    _pendingTargetOutcomes.RemoveAt(i);
                    if (pending.HealthBeforeShot <= 1 || pending.MaxHealth <= 1) {
                        MarkPendingTargetDestroyed(pending, "confirmed lethal hit");
                    }
                    else {
                        ReleasePendingTarget(pending, "hit but target survived");
                    }
                }
                else if (now - pending.FiredAt >= TargetOutcomeTimeout) {
                    _pendingTargetOutcomes.RemoveAt(i);
                    ReleasePendingTarget(pending, "outcome timeout");
                }
            }
        }
        catch (Exception ex) {
            MelonLogger.Warning($"[FCS] Target tracking: poll failed: {ex.Message}");
        }
    }

    private void ResolvePendingDestroyedTarget() {
        if (_pendingTargetOutcomes.Count == 0) {
            MelonLogger.Msg("[FCS] Target tracking: destroy observed without a tracked shot");
            return;
        }

        var index = _pendingTargetOutcomes.FindIndex(item => item.HitObservedAt > 0f);
        if (index < 0) index = 0;
        var pending = _pendingTargetOutcomes[index];
        _pendingTargetOutcomes.RemoveAt(index);
        MarkPendingTargetDestroyed(pending, "mission destroy counter");
    }

    private void MarkPendingTargetDestroyed(PendingTargetOutcome pending, string reason) {
        _autoTargetIds.Remove(pending.EntityId);
        _autoTargetRetryAfter.Remove(pending.EntityId);
        _destroyedTargetIds.Add(pending.EntityId);
        MelonLogger.Msg(
            $"[FCS] Target tracking: destroyed {pending.TargetName} [{pending.EntityId}], " +
            $"reason={reason}");
    }

    private void MarkPendingTargetHit() {
        var pending = _pendingTargetOutcomes.Find(item => item.HitObservedAt <= 0f);
        if (pending == null) {
            MelonLogger.Msg("[FCS] Target tracking: hit observed without a tracked shot");
            return;
        }
        pending.HitObservedAt = Time.realtimeSinceStartup;
        MelonLogger.Msg(
            $"[FCS] Target tracking: hit observed for {pending.TargetName} [{pending.EntityId}]");
    }

    private void ResolvePendingMissedTarget() {
        var index = _pendingTargetOutcomes.FindIndex(item => item.HitObservedAt <= 0f);
        if (index < 0) {
            MelonLogger.Msg("[FCS] Target tracking: miss observed without a tracked shot");
            return;
        }
        var pending = _pendingTargetOutcomes[index];
        _pendingTargetOutcomes.RemoveAt(index);
        ReleasePendingTarget(pending, "missed");
    }

    private void ReleasePendingTarget(PendingTargetOutcome pending, string reason) {
        _autoTargetIds.Remove(pending.EntityId);
        _autoTargetRetryAfter[pending.EntityId] =
            Time.realtimeSinceStartup + AutoTargetRetryDelay;
        MelonLogger.Msg(
            $"[FCS] Target tracking: released {pending.TargetName} [{pending.EntityId}], " +
            $"reason={reason}");
    }

    public void EnqueueTask(ArtilleryTask task) {
        if (!task.isAutoTarget && string.IsNullOrEmpty(task.sourceEntityId)) {
            if (MapTable.TryAttachSourceEntity(task, task.bulletType)) {
                MelonLogger.Msg(
                    $"[FCS] Manual target: matched T{task.targetId} to " +
                    $"{task.targetName} [{task.sourceEntityId}]");
            }
            else {
                MelonLogger.Warning(
                    $"[FCS] Manual target: T{task.targetId} has no matching FireMission entity; " +
                    "in-flight duplicate suppression is unavailable for this shot");
            }
        }

        if (!string.IsNullOrEmpty(task.sourceEntityId)) {
            if (_destroyedTargetIds.Contains(task.sourceEntityId)) {
                MelonLogger.Msg(
                    $"[FCS] Target tracking: ignored already destroyed target " +
                    $"{task.targetName} [{task.sourceEntityId}]");
                return;
            }

            // 自动任务在选择时已经占用 ID；手动任务在这里加入同一个集合。
            if (!task.isAutoTarget && !_autoTargetIds.Add(task.sourceEntityId)) {
                MelonLogger.Msg(
                    $"[FCS] Target tracking: ignored duplicate manual target " +
                    $"{task.targetName} [{task.sourceEntityId}]");
                return;
            }
        }

        task.progress = Progress.Pending;
        _taskQueue.Enqueue(task);
        TryDispatch();
    }

    /// <summary>把队首任务派给空闲炮管，直到没有空闲炮管或队列空。</summary>
    private void TryDispatch() {
        while (_taskQueue.Count > 0) {
            LeftRight slot;
            if (LeftTask == null) slot = LeftRight.Left;
            else if (RightTask == null) slot = LeftRight.Right;
            else break; // 两管炮都忙

            var task = _taskQueue.Dequeue();
            if (slot == LeftRight.Left) LeftTask = task;
            else RightTask = task;
            StartTaskRoutine(slot, task);
        }
    }

    /// <summary>
    /// 启动一个火控任务协程。用 MelonCoroutines 跑协程实现延时——
    /// 协程由 Unity 在主线程分帧驱动，yield 期间不阻塞、恢复后仍在主线程，
    /// 因此可安全访问 IL2CPP 对象。绝不能用 async/Task.Delay：其 continuation
    /// 会在线程池线程恢复，跨线程访问 IL2CPP 运行时会导致进程崩溃且无日志。
    /// </summary>
    private void StartTaskRoutine(LeftRight leftRight, ArtilleryTask task) {
        var handle = MelonCoroutines.Start(RunTaskRoutine(leftRight, task));
        _runningCoroutines.Add(handle);
    }

    /// <summary>炮管打完一发后释放槽位并尝试拉取队列里的下一个任务。</summary>
    private void ReleaseSlot(LeftRight leftRight) {
        if (leftRight == LeftRight.Left) LeftTask = null;
        else RightTask = null;
        TryDispatch();
    }

    private void CompleteTask(LeftRight leftRight, ArtilleryTask task) {
        ReleaseTargetReservation(task, AutoTargetRetryDelay, "task canceled");
        ReleaseSlot(leftRight);
    }

    private void TrackFiredTarget(ArtilleryTask task) {
        if (!string.IsNullOrEmpty(task.sourceEntityId)) {
            _pendingTargetOutcomes.Add(new PendingTargetOutcome {
                EntityId = task.sourceEntityId,
                TargetName = task.targetName,
                FiredAt = Time.realtimeSinceStartup,
                HealthBeforeShot = task.sourceHealth,
                MaxHealth = task.sourceMaxHealth
            });
            MelonLogger.Msg(
                $"[FCS] Target tracking: shot in flight to {task.targetName} " +
                $"[{task.sourceEntityId}]");
        }
    }

    private void ReleaseTargetReservation(ArtilleryTask task, float retryDelay, string reason) {
        if (string.IsNullOrEmpty(task.sourceEntityId)) return;
        _autoTargetIds.Remove(task.sourceEntityId);
        _autoTargetRetryAfter[task.sourceEntityId] = Time.realtimeSinceStartup + retryDelay;
        MelonLogger.Msg(
            $"[FCS] Target tracking: released {task.targetName} [{task.sourceEntityId}], " +
            $"reason={reason}");
    }

    private IEnumerator RunTaskRoutine(LeftRight leftRight, ArtilleryTask task) {
        var gunSys = leftRight == LeftRight.Left ? LeftGun : RightGun;

        // ===== 炮塔预约：任务一开始就在后台抢方向角并转向 =====
        // 方向旋转和装填/升仰角互不冲突。后台协程阻塞式抢炮塔锁（"一旦释放就立即获取"），
        // 一拿到就开始转向，与本任务接下来的整个装填+升仰角段重叠。等到击发前只需确认它转好，
        // 而不必等仰角转完再从头抢炮塔、再转向。方向角必须独占到这一发打出去为止，
        // 故锁一直持有到击发完成（WaitFire 后由 ReleaseOnce 归还）。
        var turret = new TurretReservation();
        // 独立的 fire-and-forget 协程，必须登记以便 Dispose 时一并 Stop，
        // 否则热重载后旧 ALC 的它仍被 Unity 驱动 → 崩溃。
        _runningCoroutines.Add(MelonCoroutines.Start(ReserveTurretAndRotate(task, turret)));
        
        var powderCount = _sceneInteractor.maxCharge ? 6 : BallisticCalculator.MinimumCharge(task.distance);

        // ===== 临界区 1：解算 =====
        // 弹道计算器 / 确认台 / 采购台都是全局唯一硬件，必须串行。算完仰角即放，
        // 让另一管炮能立刻进来算它自己的弹道，与本管炮接下来的长装填段重叠。
        float elevation = 0f;
        bool viable = true;
        yield return _deskLock.Acquire();
        try {
            task.progress = Progress.Calculating;
            yield return BallisticCalculator.SetDistance(task.distance);
            yield return BallisticCalculator.SetDirection(task.angel);
            yield return BallisticCalculator.SetCharge(powderCount);
            yield return BallisticCalculator.SetShellType(task.bulletType);
            yield return BallisticCalculator.Calculate();
            elevation = BallisticCalculator.GetElevation();

            // 装药不足则补购。单次采购未必补满（且偶发点击早于卡牌入槽而失败），
            // 故循环购买直到够本次发射所需，避免“装药不足但非 0”时直接推进、卡住后续装填。
            // 加购买次数上限兜底：采购始终无效时不至于无限循环（每次约 2.5s）。
            var plannedPurchaseCost = 0;
            if (gunSys.RemainingCharges() < powderCount) {
                plannedPurchaseCost += Math.Max(0, _purchaseDeck.GetPowderCost());
            }
            if (!gunSys.HaveBulletInCylinder(task.bulletType)) {
                plannedPurchaseCost += Math.Max(0, _purchaseDeck.GetShellCost(task.bulletType));
            }
            if (task.isAutoTarget && !CanSpendForAutoTask(plannedPurchaseCost)) {
                MelonLogger.Warning(
                    $"[FCS] {leftRight}: auto task canceled before purchasing " +
                    $"(total={RequisitionPointsMonitor.CurrentTotal}, plannedCost={plannedPurchaseCost}, " +
                    $"absoluteReserve={AbsoluteRequisitionReserve})");
                task.progress = Progress.Failed;
                viable = false;
            }

            var powderPurchaseAttempts = 0;
            while (viable && gunSys.RemainingCharges() < powderCount) {
                var powderCost = _purchaseDeck.GetPowderCost();
                if (task.isAutoTarget && !CanSpendForAutoTask(powderCost)) {
                    MelonLogger.Warning(
                        $"[FCS] {leftRight}: auto task canceled by RP reserve before powder purchase " +
                        $"(total={RequisitionPointsMonitor.CurrentTotal}, cost={powderCost}, " +
                        $"absoluteReserve={AbsoluteRequisitionReserve})");
                    task.progress = Progress.Failed;
                    viable = false;
                    break;
                }
                yield return _purchaseDeck.BuyPowders();
                if (++powderPurchaseAttempts >= 10) {
                    MelonLogger.Error(
                        $"[FCS] {leftRight} 炮管：购买装药 {powderPurchaseAttempts} 次后仍不足 " +
                        $"{powderCount}（当前 {gunSys.RemainingCharges()}），停止补购。");
                    break;
                }
            }

            if (gunSys.RemainingCharges() < powderCount) {
                task.progress = Progress.Failed;
                viable = false;
            }

            if (viable) task.progress = Progress.SelectingBullet;
            // 弹仓里没有目标弹种则采购（采购台也是共享硬件，放在锁内）。
            if (viable && !gunSys.HaveBulletInCylinder(task.bulletType)) {
                if (!gunSys.HaveEmptyShellInCylinder()) {
                    task.progress = Progress.Failed;
                    viable = false;
                }
                else {
                    var shellCost = Math.Max(0, _purchaseDeck.GetShellCost(task.bulletType));
                    if (task.isAutoTarget && !CanSpendForAutoTask(shellCost)) {
                        MelonLogger.Warning(
                            $"[FCS] {leftRight}: auto task canceled by RP reserve before " +
                            $"{task.bulletType} purchase " +
                            $"(total={RequisitionPointsMonitor.CurrentTotal}, cost={shellCost}, " +
                            $"absoluteReserve={AbsoluteRequisitionReserve})");
                        task.progress = Progress.Failed;
                        viable = false;
                    }
                    else {
                        yield return _purchaseDeck.BuyShell(task.bulletType, leftRight);
                    }
                }
            }
        }
        finally {
            _deskLock.Release();
        }

        if (!viable) {
            // 任务不可行：取消炮塔预约并归还（后台若尚未抢到，会在抢到后自行归还），
            // 并释放炮管槽位让队列里的下一个任务能用这管炮。
            turret.Canceled = true;
            ReleaseTurretOnce(turret);
            CompleteTask(leftRight, task);
            yield break;
        }

        // 允许下一任务在上一发的炮管复位期间提前完成解算与购弹，
        // 但同一炮管仍必须等到真正就绪后才能开始装填。
        yield return gunSys.WaitReadyForNextLoad();

        // ===== 锁外：装填（每管炮独立，最耗时段，可与另一管炮全程并行）=====
        task.progress = Progress.LoadingBullet;
        yield return gunSys.LoadBullet(task.bulletType);
        
        
        task.progress = Progress.LoadingPowder;
        yield return gunSys.LoadPowder(powderCount);
        task.progress = Progress.WaitLoading;
        while (!gunSys.CanFire()) {
            yield return new WaitForSeconds(1f);
        }

        // ===== 锁外：升仰角（每管炮独立，最耗时段之一）=====
        // 仰角杆是本管炮专属，不碰共享硬件；此时后台多半已把方向角转好。
        task.progress = Progress.Aiming;
        yield return gunSys.SetElevation(elevation);

        // ===== 临界区 2：击发 =====
        // 此处不再现抢炮塔——炮塔早已由后台预约持有。只等它转到位（通常已就绪，瞬间通过），
        // 然后确认+击发。炮塔锁一直由本任务持有，直到击发完成才归还。
        task.progress = Progress.WaitingForFire;
        while (!turret.Ready) {
            yield return null;
        }
        try {
            yield return TriggerConsole.ConfirmTask();
            yield return TriggerConsole.ConfirmBullet();
            yield return TriggerConsole.ConfirmRotation();
            yield return TriggerConsole.ConfirmElevation();
            yield return TriggerConsole.ReadyToFire();
            yield return TriggerConsole.Arm(leftRight);
            if (_sceneInteractor.AutoFire) {
                TriggerConsole.Fire();
            }
            yield return gunSys.WaitFire();
        }
        finally {
            ReleaseTurretOnce(turret);
        }

        // 击发确认后立即释放任务槽，让下一任务开始解算和购弹。
        // 当前任务继续独立等待复位，结束时不再清空炮管槽，以免误删新任务。
        TrackFiredTarget(task);
        ReleaseSlot(leftRight);

        // ===== 锁外：回位（仰角回 0，每管炮独立，最耗时段之一）=====
        task.progress = Progress.BackToIdle;
        yield return gunSys.WaitBackToIdle();
        task.progress = Progress.Finished;
        _sceneInteractor.TaskFinished(task);
    }

    /// <summary>
    /// 炮塔预约状态。三个标志全在主线程协作式调度下读写，无真正并发。
    /// 生命周期：后台 <see cref="ReserveTurretAndRotate"/> 抢锁→转向→置 Ready；
    /// 主流程击发后 / 任务放弃时 ReleaseTurretOnce 归还。Released 保证恰好归还一次。
    /// </summary>
    private sealed class PendingTargetOutcome {
        public string EntityId = "";
        public string TargetName = "";
        public float FiredAt;
        public float HitObservedAt;
        public int HealthBeforeShot;
        public int MaxHealth;
    }

    private sealed class TurretReservation {
        public bool Acquired;  // 已拿到炮塔锁
        public bool Ready;     // 已转到目标方向角
        public bool Canceled;  // 主流程已放弃本次预约
        public bool Released;  // 锁已归还（防重复 Release）
    }

    /// <summary>
    /// 后台预约炮塔并转向。阻塞式抢锁实现"一旦炮塔释放就立即获取"。
    /// 抢到后若发现已被取消则立即归还、不空转；否则转到目标方向并置 Ready，
    /// 此后炮塔由主流程在击发完成时归还（若转向期间被取消则在此自行归还）。
    /// </summary>
    private IEnumerator ReserveTurretAndRotate(ArtilleryTask task, TurretReservation res) {
        yield return _turretLock.Acquire();
        res.Acquired = true;
        if (res.Canceled) {
            ReleaseTurretOnce(res);
            yield break;
        }
        yield return Turret.SetRotation(task.angel);
        res.Ready = true;
        // 转向期间主流程可能已放弃（如解算失败）——此时主流程不会再击发，由这里归还。
        if (res.Canceled) {
            ReleaseTurretOnce(res);
        }
    }

    /// <summary>归还炮塔锁，保证恰好一次。仅在确实持有（Acquired）且未归还时执行。</summary>
    private void ReleaseTurretOnce(TurretReservation res) {
        if (res.Acquired && !res.Released) {
            res.Released = true;
            _turretLock.Release();
        }
    }
}
