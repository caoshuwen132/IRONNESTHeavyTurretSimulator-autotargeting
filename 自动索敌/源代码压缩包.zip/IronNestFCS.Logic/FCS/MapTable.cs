﻿using Il2Cpp;
using MelonLoader;
using UnityEngine;

namespace IronNestFCS.Logic.FCS;

public class MapTable {
    private const float MapDistanceScale = 3.8164f;
    private const float AutoTargetMaxRangeKm = 30f;
    private static readonly Vector3 GridOriginOffset = new(10.016f, 5.235f, 0f);

    private Transform? turret;
    private Dictionary<int, Transform> artilleries = new();
    private Transform? fireMissionRoot;
    private FireMission? fireMission;
    
    public bool TryBind() {
        artilleries = new Dictionary<int, Transform>();
        var turretObject = GameObject.Find("Player Turret Piece");
        if (turretObject == null) {
            MelonLogger.Warning("[FCS] 未找到 Player Turret Piece，当前场景尚未就绪");
            return false;
        }

        var mapObject = GameObject.Find("Draggable Surface");
        if (mapObject == null) {
            MelonLogger.Warning("[FCS] 未找到 Draggable Surface，当前场景尚未就绪");
            return false;
        }

        turret = turretObject.transform;
        var map = mapObject.transform;
        for (var i = 0; i < map.childCount; ++i) {
            var t = map.GetChild(i);
            if (t.name != "MapToken_Artillery") continue;
            var tmp = t.GetComponentInChildren<Il2CppTMPro.TextMeshPro>();
            if (tmp == null) continue;
            if (!int.TryParse(tmp.text, out var id)) continue;
            artilleries.Add(id, t);
        }
        MelonLogger.Msg($"[FCS] 找到 Player Turret Piece: {turret}, Artilleries: {artilleries.Count}");
        var fireMissionObject = GameObject.Find("Fire Mission Root");
        if (fireMissionObject == null) {
            MelonLogger.Warning("[FCS] 未找到 Fire Mission Root，当前场景尚未就绪");
            return false;
        }

        fireMissionRoot = fireMissionObject.transform;
        fireMission = fireMissionRoot.GetComponent<FireMission>();
        return fireMission != null;
    }

    public ArtilleryTask? GetMarkTarget(int index) {
        if (turret == null) {
            MelonLogger.Error("[FCS] GetMarkTarget: turret unbound");
            return null;
        }

        if (index > artilleries.Count) {
            MelonLogger.Error($"[FCS] GetMarkTarget: index {index} out of range, artillery count: {artilleries.Count}");
            return null;
        }

        return CreateTask(artilleries[index].localPosition);
    }

    /// <summary>
    /// 返回当前已经被任务系统发现、仍存活且静止的敌军，并按距离由近到远生成火控任务。
    /// Hidden 目标仍遵守游戏侦察规则；Moving 目标在停止前不射击，避免装填期间坐标失效。
    /// </summary>
    public List<ArtilleryTask> GetAutoTargets(BulletType bulletType) {
        var tasks = new List<ArtilleryTask>();
        if (turret == null || fireMission == null) return tasks;

        foreach (var location in GetAllFireMissionEntities()) {
            try {
                if (!location.gameObject.activeInHierarchy) continue;

                var entity = location.Entity;
                if (entity == null || !entity.IsAlive) continue;
                // IsAlive/Destroyed 在部分任务脚本中会延迟更新；Health 是受击时直接修改的可靠兜底。
                if (entity.MaxHealth > 0 && entity.Health <= 0) continue;
                if ((entity.Role & EntityRoles.Enemy) == 0) continue;
                if ((entity.State & MapEntityStates.Destroyed) != 0) continue;
                if ((entity.State & MapEntityStates.Hidden) != 0) continue;
                if ((entity.State & MapEntityStates.Moving) != 0) continue;

                var mapPosition = ConvertEntityToMapPosition(location);
                var task = CreateTask(mapPosition);
                if (float.IsNaN(task.distance) || float.IsInfinity(task.distance)
                                                   || task.distance <= 0f
                                                   || task.distance > AutoTargetMaxRangeKm) {
                    MelonLogger.Warning(
                        $"[FCS] AutoTarget: ignore invalid position for {entity.Name}: " +
                        $"{task.angel:F1} deg, {task.distance:F2} km");
                    continue;
                }
                task.sourceEntityId = string.IsNullOrWhiteSpace(entity.ID)
                    ? location.GetInstanceID().ToString()
                    : entity.ID;
                task.targetName = string.IsNullOrWhiteSpace(entity.Name)
                    ? task.sourceEntityId
                    : entity.Name;
                task.sourceIcon = entity.Icon ?? "";
                task.sourceIconSprite = GetIconSpriteName(location, entity);
                task.sourceStatusSprites = GetStatusSpriteNames(location);
                task.sourceImmuneShells = GetImmuneShells(entity);
                task.isUnderground = IsUnderground(location, entity);
                task.requiresAp = task.isUnderground || RequiresAp(entity, bulletType);
                task.isCommander = IsCommander(location, entity);
                task.isArtillery = IsArtillery(location, entity, task.isCommander);
                task.bulletType = task.requiresAp ? BulletType.AP : bulletType;
                task.isAutoTarget = true;
                task.sourceHealth = entity.Health;
                task.sourceMaxHealth = entity.MaxHealth;
                task.sourceArmour = entity.Armour;
                task.sourceStars = entity.Stars;
                task.sourceRole = entity.Role;
                task.sourceState = entity.State;
                tasks.Add(task);
            }
            catch (Exception ex) {
                // FireMission 可能恰好在扫描期间移除被摧毁实体；跳过该帧即可。
                MelonLogger.Warning($"[FCS] AutoTarget: skip stale entity: {ex.Message}");
            }
        }

        // 类型优先级和炮兵/FDC 交替由 FSC 的有状态调度器处理；这里保持同类目标由近到远。
        tasks.Sort((a, b) => a.distance.CompareTo(b.distance));
        return tasks;
    }

    /// <summary>
    /// 优先使用游戏的 Artillery 角色位；部分关卡只提供名称或图标，因此增加常见炮兵标记兜底。
    /// FDC 单独归入指挥官类别，避免同一个目标同时占用两个交替类别。
    /// </summary>
    private static bool IsArtillery(EntityLocation location, MapEntity entity, bool isCommander) {
        if (isCommander) return false;
        if ((entity.Role & EntityRoles.Artillery) != 0) return true;

        return ContainsArtilleryMarker(entity.ID)
               || ContainsArtilleryMarker(entity.Name)
               || ContainsArtilleryMarker(entity.Icon)
               || ContainsArtilleryMarker(GetIconSpriteName(location, entity));
    }

    private static bool ContainsArtilleryMarker(string? value) {
        if (string.IsNullOrWhiteSpace(value)) return false;
        return value.IndexOf("Artillery", StringComparison.OrdinalIgnoreCase) >= 0
               || value.IndexOf("Howitzer", StringComparison.OrdinalIgnoreCase) >= 0
               || value.IndexOf("Mortar", StringComparison.OrdinalIgnoreCase) >= 0
               || value.IndexOf("炮兵", StringComparison.Ordinal) >= 0
               || value.IndexOf("火炮", StringComparison.Ordinal) >= 0;
    }

    /// <summary>
    /// 炮兵指挥官在地图上使用 FDC（Fire Direction Center）标记。
    /// 同时检查任务数据中的名称/图标和运行时精灵名，以兼容不同关卡的数据写法。
    /// </summary>
    private static bool IsCommander(EntityLocation location, MapEntity entity) {
        if (ContainsCommanderMarker(entity.Name) || ContainsCommanderMarker(entity.Icon)) return true;

        try {
            var sprite = location.Image_Icon?.sprite;
            return sprite != null && ContainsCommanderMarker(sprite.name);
        }
        catch {
            return false;
        }
    }

    private static bool ContainsCommanderMarker(string? value) {
        if (string.IsNullOrWhiteSpace(value)) return false;

        if (value.IndexOf("Fire Direction Center", StringComparison.OrdinalIgnoreCase) >= 0
            || value.IndexOf("Fire_Direction_Center", StringComparison.OrdinalIgnoreCase) >= 0
            || value.IndexOf("FireDirectionCenter", StringComparison.OrdinalIgnoreCase) >= 0
            || value.IndexOf("Commander", StringComparison.OrdinalIgnoreCase) >= 0
            || value.IndexOf("炮兵指挥官", StringComparison.Ordinal) >= 0
            || value.IndexOf("射击指挥官", StringComparison.Ordinal) >= 0
            || value.IndexOf("射擊指揮官", StringComparison.Ordinal) >= 0) {
            return true;
        }

        // FDC 必须是独立缩写，避免误判名称中偶然出现的三个字母。
        for (var i = 0; i <= value.Length - 3; i++) {
            if (!value.AsSpan(i, 3).Equals("FDC".AsSpan(), StringComparison.OrdinalIgnoreCase)) continue;

            var leftBoundary = i == 0 || !char.IsLetterOrDigit(value[i - 1]);
            var rightIndex = i + 3;
            var rightBoundary = rightIndex == value.Length || !char.IsLetterOrDigit(value[rightIndex]);
            if (leftBoundary && rightBoundary) return true;
        }

        return false;
    }

    /// <summary>
    /// 地下目标可能使用 Enemy_Underground Fort 状态图标，也可能只在主图标中使用 Bunker 名称。
    /// 名称、数据图标、原始精灵、运行时精灵和对象名都检查，兼容 FDC 与补给掩体等不同关卡写法。
    /// </summary>
    private static bool IsUnderground(EntityLocation location, MapEntity entity) {
        // 绿色“地下 / 需要 AP”标识由 Armour 显示层生成，主 FDC 图标和 Role 都可能仍是普通值。
        if (entity.Armour > 0) return true;

        // 游戏用 Fortification 类型位生成“地下 / 需要 AP 弹”的附加单位信息；它不一定写入主图标。
        if ((entity.Role & EntityRoles.Fortification) != 0) return true;

        if (ContainsUnderground(entity.ID)
            || ContainsUnderground(entity.Name)
            || ContainsUnderground(entity.Icon)
            || ContainsUnderground(GetIconSpriteName(location, entity))
            || ContainsUnderground(location.gameObject.name)) {
            return true;
        }

        if (HasUndergroundStatusIcon(location)) return true;

        try {
            var sprite = location.Image_Icon?.sprite;
            return sprite != null && ContainsUnderground(sprite.name);
        }
        catch {
            // 某些地图实体在销毁过程中会先释放 UI 引用；此时按普通目标处理。
            return false;
        }
    }

    /// <summary>检查目标下面实际可见的状态图标，包括主图标之外单独叠加的绿色地下标识。</summary>
    private static bool HasUndergroundStatusIcon(EntityLocation location) {
        try {
            var images = location.GetComponentsInChildren<UnityEngine.UI.Image>(true);
            foreach (var image in images) {
                if (image == null || !image.enabled || !image.gameObject.activeInHierarchy) continue;
                if (ContainsUnderground(image.gameObject.name)
                    || ContainsUnderground(image.sprite?.name)) {
                    return true;
                }
            }
        }
        catch {
            // UI 正在销毁或重建时由其他数据字段继续判定。
        }
        return false;
    }

    private static bool ContainsUnderground(string? value) {
        return !string.IsNullOrEmpty(value)
               && (value.IndexOf("Underground", StringComparison.OrdinalIgnoreCase) >= 0
                   || value.IndexOf("Bunker", StringComparison.OrdinalIgnoreCase) >= 0);
    }

    /// <summary>
    /// 游戏命中判定会读取 MapEntity.ImmuneShells。即使关卡没有在主图标名里写 Underground，
    /// 只要当前弹种在免疫列表里而 AP 不在，就按游戏自身规则切换为 AP。
    /// </summary>
    private static bool RequiresAp(MapEntity entity, BulletType selectedBulletType) {
        if (selectedBulletType == BulletType.AP) return false;
        return IsImmuneTo(entity, selectedBulletType) && !IsImmuneTo(entity, BulletType.AP);
    }

    private static bool IsImmuneTo(MapEntity entity, BulletType bulletType) {
        var immuneShells = entity.ImmuneShells;
        if (immuneShells == null) return false;

        var shellId = bulletType.ToString();
        foreach (var immuneShell in immuneShells) {
            if (string.Equals(immuneShell, shellId, StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    private static string GetImmuneShells(MapEntity entity) {
        var immuneShells = entity.ImmuneShells;
        if (immuneShells == null) return "";

        var values = new List<string>();
        foreach (var immuneShell in immuneShells) {
            if (!string.IsNullOrWhiteSpace(immuneShell)) values.Add(immuneShell);
        }
        return string.Join(",", values);
    }

    private static string GetIconSpriteName(EntityLocation location, MapEntity entity) {
        try {
            if (entity.IconRaw != null && !string.IsNullOrWhiteSpace(entity.IconRaw.name)) {
                return entity.IconRaw.name;
            }
            return location.Image_Icon?.sprite?.name ?? "";
        }
        catch {
            return "";
        }
    }

    private static string GetStatusSpriteNames(EntityLocation location) {
        try {
            var values = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var images = location.GetComponentsInChildren<UnityEngine.UI.Image>(true);
            foreach (var image in images) {
                if (image == null || !image.enabled || !image.gameObject.activeInHierarchy) continue;
                var spriteName = image.sprite?.name;
                if (!string.IsNullOrWhiteSpace(spriteName)) values.Add(spriteName);
            }
            return string.Join(",", values);
        }
        catch {
            return "";
        }
    }

    /// <summary>
    /// EntityLocation.LocalPosition 属于 FireMission 的 RectTransform 坐标系，不能和地图炮塔的
    /// localPosition 直接相减。通过世界坐标把实体标记转换到炮塔父节点坐标系，得到与手动
    /// MapToken_Artillery 相同的地图坐标；忽略 Z 轴的 UI 层级偏移，只在地图 XY 平面解算。
    /// </summary>
    private Vector3 ConvertEntityToMapPosition(EntityLocation location) {
        if (turret == null) throw new InvalidOperationException("Map turret is not bound.");

        var mapSpace = turret.parent;
        var result = mapSpace != null
            ? mapSpace.InverseTransformPoint(location.transform.position)
            : location.transform.position;
        result.z = turret.localPosition.z;
        return result;
    }

    private ArtilleryTask CreateTask(Vector3 targetLocalPosition) {
        if (turret == null) throw new InvalidOperationException("Map turret is not bound.");

        var target = targetLocalPosition - turret.localPosition;
        var dist = target.magnitude * MapDistanceScale;
        var angle = Vector3.SignedAngle(target, Vector3.up, Vector3.forward);
        if (angle < 0) angle += 360;
        return new ArtilleryTask {
            angel = angle,
            distance = dist,
            position = targetLocalPosition * MapDistanceScale + GridOriginOffset
        };
    }

    public List<EntityLocation> GetAllFireMissionEntities() {
        List<EntityLocation> res = new();
        if (fireMissionRoot == null) {
            return res;
        }

        for (var i = 0; i < fireMissionRoot.childCount; ++i) {
            var m = fireMissionRoot.GetChild(i).GetComponent<EntityLocation>();
            if (m != null) res.Add(m);
        }
        return res;
    }
    
}
